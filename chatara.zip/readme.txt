Thanks for use our font
_______________________
Please contact us before any commercial use. 
Our fonts for free use allowed only in personal project , non-profit and charity use. 
If you make money from using my fonts, Please purchase a commercial license in
https://saxofont.com/product/chatara-sans/
https://www.creativefabrica.com/product/chatara/

Saxofont™ 
Instagram : @saxofont.id